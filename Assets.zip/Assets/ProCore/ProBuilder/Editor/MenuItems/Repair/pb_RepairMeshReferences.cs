namespace ProBuilder2.Actions
{
	/**
	 *	File stub retained for backwards compatibility.
	 *	You may safely delete this file.
	 */
	[System.Obsolete]
	static class pb_RepairMeshReferences {}
}
